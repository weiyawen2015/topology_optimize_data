%MAKE_ALL Make for all of stenglib/.

% S. Engblom 2010-09-23

cd Tensor
startup
make

cd ../Fast
startup
make

cd ..