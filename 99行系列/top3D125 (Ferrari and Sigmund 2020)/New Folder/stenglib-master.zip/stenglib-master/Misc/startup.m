%STARTUP Add paths to MISC stuff.

% S. Engblom 2010-02-10

s = pwd;
% (do nothing)
