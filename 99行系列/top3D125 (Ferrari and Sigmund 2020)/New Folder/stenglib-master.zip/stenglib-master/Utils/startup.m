%STARTUP Add paths to UTILS stuff.

% S. Engblom 2010-02-10 (Revision)
% S. Engblom 2005-03-22

s = pwd;
if exist('test','dir')
  addpath([s '/test']);
end

