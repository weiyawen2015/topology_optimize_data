%STARTUP Add paths to stenglib/.

% S. Engblom 2005-03-22

s = pwd;
addpath([s '/Tensor']);
addpath([s '/Fast']);
addpath([s '/Utils']);
addpath([s '/Scicomp']);
addpath([s '/Misc']);
